package com.example.screenmirror

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var prefs: SharedPreferences
    private lateinit var portInput: EditText
    private lateinit var status: TextView
    private lateinit var toggle: Button

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val data = result.data
            if (result.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenStreamService::class.java)
                    .putExtra("resultCode", result.resultCode)
                    .putExtra("data", data)
                    .putExtra("port", prefs.getInt("port", 8080))
                    .putExtra("quality", prefs.getInt("quality", 70))
                    .putExtra("scale", prefs.getInt("scale", 60))
                    .putExtra("fps", prefs.getInt("fps", 15))
                ContextCompat.startForegroundService(this, i)
                refreshLater()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", Context.MODE_PRIVATE)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        root.addView(TextView(this).apply {
            text = "Screen Mirror"
            textSize = 24f
        })

        addSlider(root, "Bildqualität", 30, 95, "quality", 70, " %")
        addSlider(root, "Größe", 25, 100, "scale", 60, " %")
        addSlider(root, "Bilder pro Sekunde", 5, 30, "fps", 15, "")

        root.addView(TextView(this).apply { text = "Port" })
        portInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(prefs.getInt("port", 8080).toString())
        }
        root.addView(portInput)

        toggle = Button(this).apply { setOnClickListener { onToggle() } }
        root.addView(toggle)

        status = TextView(this).apply {
            textSize = 16f
            setPadding(0, pad, 0, 0)
            setTextIsSelectable(true)
        }
        root.addView(status)

        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun onToggle() {
        if (ScreenStreamService.running) {
            stopService(Intent(this, ScreenStreamService::class.java))
            refreshLater()
            return
        }
        val port = portInput.text.toString().toIntOrNull()
        if (port == null || port !in 1024..65535) {
            Toast.makeText(this, "Port muss zwischen 1024 und 65535 liegen", Toast.LENGTH_LONG).show()
            return
        }
        prefs.edit().putInt("port", port).apply()
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }

    private fun addSlider(
        root: LinearLayout, label: String, min: Int, max: Int,
        key: String, default: Int, unit: String
    ) {
        val current = prefs.getInt(key, default)
        val tv = TextView(this).apply { text = "$label: $current$unit" }
        val sb = SeekBar(this).apply {
            this.max = max - min
            progress = current - min
        }
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                tv.text = "$label: ${p + min}$unit"
                prefs.edit().putInt(key, p + min).apply()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(tv)
        root.addView(sb)
    }

    private fun refreshLater() {
        Handler(Looper.getMainLooper()).postDelayed({ refresh() }, 600)
    }

    private fun refresh() {
        if (ScreenStreamService.running) {
            toggle.text = "Übertragung stoppen"
            status.text = "Läuft. Öffne diese Adresse im Browser deines Fernsehers " +
                "(gleiches WLAN):\n\n${ScreenStreamService.url}"
        } else {
            toggle.text = "Übertragung starten"
            status.text = "Gestoppt."
        }
    }
}
