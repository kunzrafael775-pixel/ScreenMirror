package com.example.screenmirror

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import java.io.BufferedOutputStream
import java.io.BufferedReader
import java.io.ByteArrayOutputStream
import java.io.InputStreamReader
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.TimeUnit

class ScreenStreamService : Service() {

    companion object {
        @Volatile var running = false
        @Volatile var url: String? = null

        fun localIp(): String? = try {
            NetworkInterface.getNetworkInterfaces().toList()
                .flatMap { it.inetAddresses.toList() }
                .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
                ?.hostAddress
        } catch (e: Exception) {
            null
        }
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var serverSocket: ServerSocket? = null
    private var scheduler: ScheduledExecutorService? = null
    private val pool = Executors.newCachedThreadPool()

    @Volatile private var frame: ByteArray? = null
    @Volatile private var frameId = 0L

    private var width = 0
    private var height = 0
    private var quality = 70

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForegroundNotification()

        val resultCode = intent.getIntExtra("resultCode", 0)
        val data: Intent? = if (Build.VERSION.SDK_INT >= 33) {
            intent.getParcelableExtra("data", Intent::class.java)
        } else {
            @Suppress("DEPRECATION") intent.getParcelableExtra("data")
        }
        val port = intent.getIntExtra("port", 8080)
        val scale = intent.getIntExtra("scale", 60)
        val fps = intent.getIntExtra("fps", 15)
        quality = intent.getIntExtra("quality", 70)

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(resultCode, data)
        projection = p
        // Ab Android 14 Pflicht: Callback vor createVirtualDisplay registrieren
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, Handler(Looper.getMainLooper()))

        startCapture(p, scale, fps)
        running = true
        url = "http://${localIp() ?: "?"}:$port"
        startServer(port, fps)
        return START_NOT_STICKY
    }

    private fun startForegroundNotification() {
        val channelId = "mirror"
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Bildschirmübertragung", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, channelId)
            .setContentTitle("Bildschirm wird übertragen")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    private fun startCapture(p: MediaProjection, scalePercent: Int, fps: Int) {
        val dm = resources.displayMetrics
        width = (dm.widthPixels * scalePercent / 100) and 1.inv()
        height = (dm.heightPixels * scalePercent / 100) and 1.inv()

        val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader = reader
        virtualDisplay = p.createVirtualDisplay(
            "ScreenMirror", width, height, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader.surface, null, null
        )

        // Regelmäßig das neueste Bild holen (null, wenn sich nichts geändert hat)
        val s = Executors.newSingleThreadScheduledExecutor()
        scheduler = s
        s.scheduleAtFixedRate({ grabFrame() }, 0, 1000L / fps, TimeUnit.MILLISECONDS)
    }

    private fun grabFrame() {
        try {
            val image = imageReader?.acquireLatestImage() ?: return
            try {
                val plane = image.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * width
                val full = Bitmap.createBitmap(
                    width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888
                )
                full.copyPixelsFromBuffer(plane.buffer)
                val bmp = if (rowPadding > 0) Bitmap.createBitmap(full, 0, 0, width, height) else full
                val out = ByteArrayOutputStream()
                bmp.compress(Bitmap.CompressFormat.JPEG, quality, out)
                frame = out.toByteArray()
                frameId++
            } finally {
                image.close()
            }
        } catch (e: Exception) {
            // Einzelnes Bild überspringen
        }
    }

    private fun startServer(port: Int, fps: Int) {
        pool.execute {
            try {
                val ss = ServerSocket(port)
                serverSocket = ss
                while (!ss.isClosed) {
                    val client = ss.accept()
                    pool.execute {
                        try {
                            handleClient(client, fps)
                        } catch (e: Exception) {
                            // Verbindung getrennt
                        }
                    }
                }
            } catch (e: Exception) {
                // Server beendet
            }
        }
    }

    private fun handleClient(socket: Socket, fps: Int) {
        socket.use {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val requestLine = reader.readLine() ?: return
            val path = requestLine.split(" ").getOrNull(1) ?: "/"
            val out = BufferedOutputStream(socket.getOutputStream())

            if (path.startsWith("/stream")) {
                out.write(
                    ("HTTP/1.1 200 OK\r\n" +
                        "Content-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray()
                )
                var lastId = -1L
                var lastSent = 0L
                while (!socket.isClosed && running) {
                    val f = frame
                    val id = frameId
                    val now = SystemClock.elapsedRealtime()
                    if (f != null && (id != lastId || now - lastSent > 1000)) {
                        out.write(
                            ("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n")
                                .toByteArray()
                        )
                        out.write(f)
                        out.write("\r\n".toByteArray())
                        out.flush()
                        lastId = id
                        lastSent = now
                    }
                    Thread.sleep(1000L / fps)
                }
            } else {
                val html = "<!DOCTYPE html><html><head>" +
                    "<meta name='viewport' content='width=device-width,initial-scale=1'>" +
                    "<style>html,body{margin:0;height:100%;background:#000}" +
                    "img{width:100%;height:100%;object-fit:contain}</style></head>" +
                    "<body><img src='/stream'></body></html>"
                val body = html.toByteArray()
                out.write(
                    ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n" +
                        "Content-Length: ${body.size}\r\nConnection: close\r\n\r\n").toByteArray()
                )
                out.write(body)
                out.flush()
            }
        }
    }

    override fun onDestroy() {
        running = false
        url = null
        scheduler?.shutdownNow()
        virtualDisplay?.release()
        imageReader?.close()
        try { serverSocket?.close() } catch (e: Exception) {}
        pool.shutdownNow()
        val p = projection
        projection = null
        p?.stop()
        super.onDestroy()
    }
}
